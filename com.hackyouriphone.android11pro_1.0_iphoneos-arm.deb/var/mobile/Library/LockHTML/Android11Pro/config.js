var MainColor = "Black";
var DayColor = "Black";
var StripeColor = "DarkGrey";
var DarkIcon = true;
var ZoomLevel = 90;
var MainText = "I hope today is as fantastic as you are, you deserve the best and nothing less.<br>Have a great day and enjoy life.";
