function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function Fish() {
  this.top = getRandomInt(0, 100);
  this.left = getRandomInt(0, 100);
  this.distance = 0;
  this.vDistance = 0;

  this.type = getRandomInt(0, 1);

  this.direction = getRandomInt(0, 1) || -1;

  this.element = jQuery(
  '<div class="fish fish-' + this.type + '"><div class="inner"></div></div>');


  this.element.css({
    top: this.top + "%",
    left: this.left + "%",
    transform: "translate3d(0, 0, 0)" });


  jQuery("body").append(this.element);

  this.element.css("width");
}

Fish.prototype.swim = function () {
  var that = this,
  distance = getRandomInt(-600, 600),
  vDistance = getRandomInt(-200, 200),
  duration = getRandomInt(3000, 6000);

  if (distance < 0) {
    this.direction = 1;
  } else {
    this.direction = -1;
  }

  if (this.direction === -1) {
    this.element.children(".inner").addClass("right");
  } else {
    this.element.children(".inner").removeClass("right");
  }

  this.distance += distance;
  this.vDistance += vDistance;

  this.element.css({
    "transition-duration": duration + "ms",
    "transform": "translate3d(" + this.distance + "%, " + this.vDistance + "%, 0)" });


  setTimeout(function () {
    that.swim();
  }, duration + 100);
};

for (var i = 0; i < 20; i++) {
  var fish = new Fish();
  fish.swim();
}