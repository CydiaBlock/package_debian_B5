function NumberToWords(e) {
    var words = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen',
        'Eighteen', 'Nineteen', 'Twenty'
    ];
    words[30] = 'Thirty';
    words[40] = 'Forty';
    words[50] = 'Fifty';
    words[60] = 'Sixty';
    words[70] = 'Seventy';
    words[80] = 'Eighty';
    words[90] = 'Ninety';
    amount = e.toString();
    var atemp = amount.split(".");
    var number = atemp[0].split(",").join("");
    var n_length = number.length;
    var word = "";
    if (n_length <= 9) {
        var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
        var received_n_array = new Array();
        for (var i = 0; i < n_length; i++) {
            received_n_array[i] = number.substr(i, 1);
        }
        for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
            n_array[i] = received_n_array[j];
        }
        for (var i = 0, j = 1; i < 9; i++, j++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                if (n_array[i] == 1) {
                    n_array[j] = 10 + parseInt(n_array[j]);
                    n_array[i] = 0;
                }
            }
        }
        value = "";
        for (var i = 0; i < 9; i++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                value = n_array[i] * 10;
            } else {
                value = n_array[i];
            }
            if (value != 0) {
                word += words[value] + " ";
            }
        }
        word = word.split("  ").join(" ");
    }
    return word;
}


function setDate() {
    const text = document.getElementsByClassName('time')[0];
    const Time = new Date();
    //const Hours = Time.getHours();
    var Hours12 = Time.getHours() % 12 || 12;
    const Minutes = Time.getMinutes();
    //const AMPM = Hours >= 12 ? 'pm' : 'am';
	
	if (Hours12 > 11) {
		Hours12 = Hours12 - 12;
	}

    if (Minutes <= 0) {
        text.innerHTML = NumberToWords(Hours12) + " O' Clock";
        console.log(NumberToWords(Hours12) + " O' Clock ");
    } else
    if (Minutes === 1) {
        text.innerHTML = NumberToWords(Minutes) + "Minute Past " + NumberToWords(Hours12);
    } else

    if (Minutes === 59) {
        var tmp = [60 - Minutes];
        var tmp1 = [Hours12 + 1];
        //Hours12 = Hours12 + "1" 
        text.innerHTML = NumberToWords(tmp) + " Minute To " + NumberToWords(tmp1);
    } else
    if (Minutes === 15) {
        text.innerHTML = "Quarter Past  " + NumberToWords(Hours12);
    } else
    if (Minutes === 30) {
        text.innerHTML = "Half Past " + NumberToWords(Hours12);
    } else
    if (Minutes === 45) {
        var tmp1 = [Hours12 + 1];
        text.innerHTML = "Quarter To " + NumberToWords(tmp1);
    } else

    if (Minutes <= 30) {
        text.innerHTML = NumberToWords(Minutes) + "Minutes Past " + NumberToWords(Hours12);
    } else

    if (Minutes > 30) {
        var tmp = [60 - Minutes];
        var tmp1 = [Hours12 + 1];
        text.innerHTML = NumberToWords(tmp) + " Minutes To " + NumberToWords(tmp1);
    }

}
setInterval(setDate, 1000);