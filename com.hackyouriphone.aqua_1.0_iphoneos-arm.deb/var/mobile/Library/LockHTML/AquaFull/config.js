var HeaderColor = "DarkGrey"; // Enter Background Header Color
var HeaderColor2nd = "Yellow"; // Enter Foreground Header Color
var ColourStyle = "Yellow"; // Enter Box Color
var IconBrightness = 0; // Set Icon Brightness
