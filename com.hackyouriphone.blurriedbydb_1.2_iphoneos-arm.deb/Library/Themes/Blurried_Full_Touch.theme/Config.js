// Configuration here ! //
// Made by Dacal for Durben 
// For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)


// SET YOUR iPHONE SIZE BELOW

var iPhone5 = true;  // If you are using an iPhone 4 or 4S set this to false. 

// BLUR OPTION BELOW

var alwaysBlur = false; // Set to true to blur your chosen wallpaper at all times. false to have it blur only when you tap the screen to show the forecast 

var ampm = true; // Set to true for 12h format

// SET YOUR WEATHER AND LANGUAGE OPTIONS BELOW

var gps = true; // You NEED to install crazyvivek's "GPS Weather Lockscreen" for GPS localization
var locale = 9807; // Yahoo Weather (used if gps set to false or myLocation.txt file not found)
/*
Options below are for specific situations.
*/
var UseCityGPS = false; // If your city is innacurate with Yahoo RSS, you can try to use the GPS localization (if available).
var UseNeighborhood = false; // If your city is inaccurate with GPS localization, you can try to use the neighborhood (or state).

var tempUnit = "c"; // f for fahrenheit
var updateInterval = 15; // in minutes
var lang = "en"; // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) or anything else for english,(am) for us



