
function mainUpdate(type){

  if(type == "weather"){

document.getElementById('weatherIcon').src = 'img/icon/' + weather.conditionCode + ".png";
 
document.getElementById('wthr').innerHTML = weatherdesc[weather.conditionCode];

document.getElementById('temp').innerHTML = weather.temperature + "&deg;" + weather.celsius;

document.getElementById('lowtemp').innerHTML = weather.low + "&deg;⇩";

document.getElementById('hightemp').innerHTML = weather.high + "&deg;⇧";

      
}

	var val = parseInt(weather.temperature);
  var $circle = $('#svg #bar'); 
            var r = $circle.attr('r');
    var c = Math.PI*(r*2);
   
    if (val < 0) { val = 0;}
    if (val > 100) { val = 100;}
    
    var pct = ((100-val)/100)*c;
    
    $circle.css({ strokeDashoffset: pct});
    
    $('#tmp').attr('tep-pct',val);

		
    if(type == "battery"){

//battery
         var val = parseInt(batteryPercent);
  var $circle = $('#svg0 #bar0'); 
            var r = $circle.attr('r');
    var c = Math.PI*(r*2);
   
    if (val < 0) { val = 0;}
    if (val > 100) { val = 100;}
    
    var pct = ((100-val)/100)*c;
    
    $circle.css({ strokeDashoffset: pct});
    
    $('#bat').attr('bat-pct',val);

if(batteryCharging == 0){

 document.getElementById('dis').style.visibility = 'visible';

 document.getElementById('char').style.visibility = 'hidden';

}

   if(batteryCharging == 1){

 document.getElementById('char').style.visibility = 'visible';

 document.getElementById('dis').style.visibility = 'hidden';

}

if(batteryCharging == 0){

charge.style.visibility = 'hidden';
apple.style.visibility = 'visible';
}

if(batteryCharging == 1){

charge.style.visibility = 'visible';
apple.style.visibility = 'hidden';

}

}


if(type == "statusbar"){

 if(wifiBars == "0") {
           
document.getElementById("wifi0").style.display= 'none';

        } 

        else if(wifiBars == "1") {
wifi2.style.visibility = 'hidden';
wifi3.style.visibility = 'hidden';

        } 
        else if(wifiBars == "2") {
wifi2.style.visibility = 'visible';
wifi3.style.visibility = 'hidden';
        }
       else if(wifiBars == "3") {
wifi2.style.visibility = 'visible';
wifi3.style.visibility = 'visible';

        }
        

        if(signalBars == "0") {
signal1.style.visibility = 'hidden';

        } 

        else if(signalBars == "1") {
sig1.style.visibility = 'visible';
sig2.style.visibility = 'hidden';
sig3.style.visibility = 'hidden';
sig4.style.visibility = 'hidden';
        } 
        else if(signalBars == "2") {
sig1.style.visibility = 'visible';
sig2.style.visibility = 'visible';
sig3.style.visibility = 'hidden';
sig4.style.visibility = 'hidden';
        }
        else if(signalBars == "3") {
sig1.style.visibility = 'visible';
sig2.style.visibility = 'visible';
sig3.style.visibility = 'visible';
sig4.style.visibility = 'hidden';
        }
        else if(signalBars == "4") {
sig1.style.visibility = 'visible';
sig2.style.visibility = 'visible';
sig3.style.visibility = 'visible';
sig4.style.visibility = 'visible';

        }
	    }
			
			if(type == "system"){

document.getElementById('device').innerHTML = deviceType;

document.getElementById('ios').innerHTML = "IOS" + " : " + systemVersion;

}


};


function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
timeOfDay = ( currentHours < 12 ) ? "" : "";

if (Clock == true){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "" : "" ) + currentHours;
	currentTimeString = currentHours +  currentMinutes;
}

if (Clock == false){
currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
currentHours = ( currentHours == 0 ) ? "12" : currentHours;
currentHours = ( currentHours == 13 ) ? "01" : currentHours;
currentHours = ( currentHours == 14 ) ? "02" : currentHours;
currentHours = ( currentHours == 15 ) ? "03" : currentHours;
currentHours = ( currentHours == 16 ) ? "04" : currentHours;
currentHours = ( currentHours == 17 ) ? "05" : currentHours;
currentHours = ( currentHours == 18 ) ? "06" : currentHours;
currentHours = ( currentHours == 19 ) ? "07" : currentHours;
currentHours = ( currentHours == 20 ) ? "08" : currentHours;
currentHours = ( currentHours == 21 ) ? "09" : currentHours;
currentHours = ( currentHours == 22 ) ? "10" : currentHours;
currentHours = ( currentHours == 23 ) ? "11" : currentHours;
currentHours = ( currentHours == 24 ) ? "12" : currentHours;
currentTimeString = currentHours + ":" + currentMinutes;
}

 

document.getElementById("hour").innerHTML = currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("ampm").innerHTML = timeOfDay;

document.getElementById("date").innerHTML = " "+currentDate;
document.getElementById("month").innerHTML = shortmonths[currentTime.getMonth()];

document.getElementById("year").innerHTML = currentTime.getFullYear();

if (shortdays[currentTime.getDay()]  == "Sun"){
document.getElementById("Sun").style.color = DayColor;

}

if (shortdays[currentTime.getDay()]  == "Mon"){

document.getElementById("Mon").style.color = DayColor;

}
if (shortdays[currentTime.getDay()]  == "Tue"){

document.getElementById("Tue").style.color = DayColor;

}
if (shortdays[currentTime.getDay()]  == "Wed"){
document.getElementById("Wed").style.color = DayColor;
}
if (shortdays[currentTime.getDay()]  == "Thu"){

document.getElementById("Thu").style.color = DayColor;

}
if (shortdays[currentTime.getDay()]  == "Fri"){

document.getElementById("Fri").style.color = DayColor;

}
if (shortdays[currentTime.getDay()]  == "Sat"){

document.getElementById("Sat").style.color = DayColor;
}

document.getElementById("weekday").style.color = DayColor;

document.getElementById("weekday"). innerHTML = shortdays[currentTime.getDay()];


}

function init(){
updateClock();
setInterval("updateClock();", 1000);

}
