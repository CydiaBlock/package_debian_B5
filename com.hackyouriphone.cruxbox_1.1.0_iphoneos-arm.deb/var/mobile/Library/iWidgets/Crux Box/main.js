/* Copyright © 0neguy Inc. 2019 */

var $ = document;
var d = new Date();
var day = document.getElementById("day");
var box = document.getElementById("box")
var dateMonth = document.getElementById("date-month");
var searchImg = document.getElementById("searchImg")
var searchButton = document.getElementById("searchButton")

$.addEventListener("touchstart", function () {}, false);

function debug() {
    document.getElementById("debug").innerHTML = ""
    document.getElementById("debug").innerHTML += "isDarkMode: " + isDarkMode + "<br>"
    document.getElementById("debug").innerHTML += "widgetSize: " + widgetSize + "<br>"
    document.getElementById("debug").innerHTML += "boxColor: " + boxColor + "<br>"
    document.getElementById("debug").innerHTML += "dateMonthColor: " + dateMonthColor + "<br>"
    document.getElementById("debug").innerHTML += "searchColor: " + searchColor + "<br>"
    document.getElementById("debug").innerHTML += "searchIcon: " + searchIcon + "<br>"
    document.getElementById("debug").innerHTML += "searchAction: " + searchAction + "<br>"
    document.getElementById("debug").innerHTML += "isDebugMode: " + isDebugMode + "<br>"
}

function prefs() {
    if (isDebugMode === 1) {
        debug();
        document.getElementById("debug").style.display = "block";
    } else if (isDebugMode === 0) {
        // Nothing
    }

    if (searchAction === "spotlight") {
        searchButton.setAttribute("onclick", "window.location = 'xeninfo:openspotlight';")
    } else if (searchAction === "safari") {
        searchButton.setAttribute("onclick", "window.location = 'xeninfo:openapp:com.apple.mobilesafari';")
    } else if (searchAction === "google") {
        searchButton.setAttribute("onclick", "window.location = 'xeninfo:openapp:com.google.GoogleMobile';")
    }

    box.style.transform = "scale(" + widgetSize + ")"
    searchImg.setAttribute("src", "img/" + searchIcon + ".png")
    if (isDarkMode === 0) {
        box.style.background = boxColor;
        searchButton.style.background = searchColor;
        dateMonth.style.color = dateMonthColor;
        day.style.color = dayColor;
    } else if (isDarkMode === 1) {
        darkMode();
    }
}

function update() {
    let dayStr = d.getDay();
    let monthStr = d.getMonth();
    if (dayStr === 1) {
        day.innerHTML = "Mon,"
    } else if (dayStr === 2) {
        day.innerHTML = "Tue,";
    } else if (dayStr === 3) {
        day.innerHTML = "Wed,";
    } else if (dayStr === 4) {
        day.innerHTML = "Thu,";
    } else if (dayStr === 5) {
        day.innerHTML = "Fri,";
    } else if (dayStr === 6) {
        day.innerHTML = "Sat,";
    } else if (dayStr === 0) {
        day.innerHTML = "Sun,";
    };

    let monthText;
    if (monthStr === 0) {
        monthText = "January";
    } else if (monthStr === 1) {
        monthText = "February";
    } else if (monthStr === 2) {
        monthText = "March";
    } else if (monthStr === 3) {
        monthText = "April";
    } else if (monthStr === 4) {
        monthText = "May";
    } else if (monthStr === 5) {
        monthText = "June";
    } else if (monthStr === 6) {
        monthText = "July";
    } else if (monthStr === 7) {
        monthText = "August";
    } else if (monthStr === 8) {
        monthText = "September";
    } else if (monthStr === 9) {
        monthText = "October";
    } else if (monthStr === 10) {
        monthText = "November";
    } else if (monthStr === 11) {
        monthText = "December";
    };

    dateMonth.innerHTML = monthText + " " + d.getDate();
};

function darkMode() {
    box.style.background = "#303030";
    searchButton.style.background = "#505050";
    dateMonth.style.color = "#848484"
}

setTimeout(function () {
    update();
}, 900000)

update();