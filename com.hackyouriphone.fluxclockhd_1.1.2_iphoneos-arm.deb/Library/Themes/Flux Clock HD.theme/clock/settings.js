//NOTICE/// This settings file is now only used for setting the default values of variables and changing advanced settings.   For all other changes, you should use the settings panel in the lockscreen itself////

digital = true;    				// whether to display the digital clock

date = true;       				// whether to display the date

hour24 = true;     				// whether to use 24 hour time

textcolor = "#FEFEFE"; 	   				//Text color, or all color if multicolor is set to false (you may replace the numbers with a common colorname if you wish, but DO NOT remove the parenthesis)

//"#FEFEFE","#747474","#F10000" red, grey and white
cols = Array("#FEFEFE","#FEFEFE","#FEFEFE"); 	//Color of time indicator rings; 1 is hours, 2 is minutes, and 3 is seconds(you may replace the numbers with common colornames ie "blue", or "white")

sblur = 20;                     // shadow blur This determines how much things "glow" Default is 20