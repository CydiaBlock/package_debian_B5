# Forest #

### インストール ###
- App StoreアプリでXCode7を検索してインストール
- Forestの最新リリースをダウンロードし展開
- 展開したフォルダのForest.xcworkspaceをXCode7で開く
- iOSデバイスをMacにつなぐ
- XCode左上部でデバイスを選択(「iOS Device」等)
- XCode左上部の音楽再生ボタンによく似た実行ボタンを押す


### 開発メモ ###

 1.   FastTableView関連
  - 通常モードでは表示する前にTableViewのCellの表示内容を準備しておく必要があるが、
    tableView.bounds.size.widthは表示する前には設定されていないので、cellの内容を決定
    する前に、外部から横幅を手動で教えておかなければいけない。
 1. FastTableViewではReloadDataまたはReloadTableViewAtRowなどの他
　　行数の変更を伴うものに対しては全てTableView自体のsynchronized下で行う。


* Swiftを導入しようと思ったけど、規模が大きくなるとビルド時間が問題になるみたいなので中止し、Objective-C一本で行くことに。Swiftを導入しようと思ったのは、ヘッダファイルがいらなくなってファイル一覧がスッキリさせることが主な目的だったけど、Project Navigatorでヘッダーをフォルダごとにサブフォルダ化することでとりあえず凌ぐことにした。

