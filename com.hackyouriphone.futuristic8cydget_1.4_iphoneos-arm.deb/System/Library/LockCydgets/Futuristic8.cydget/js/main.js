if( /iPhone|iPad|iPod/i.test(navigator.userAgent) ) {
    var clickType = "touchstart";
    var padzero = false;
}else{
    var clickType = "click";
    getBattery = function(){return 50;};
    getBattStat = function(){return "Charging";};
    unlock = function(){alert("Unlock");};
    var WD = "N"; //wind direction
    getEL('windval').innerHTML="15";
    getEL('tempval').innerHTML="15&deg;";
    var padzero = false;
    var settingsObject = {};
    settingsObject['celsius'] = "C";
    settingsObject['twentyfour'] = false;
    settingsObject['padzero'] = false;
    settingsObject['basecolor'] = "#18EBED";
    settingsObject['strokecolor'] = "#18EBED";
    settingsObject['startnow'] = false;
    deSVG('.weather', true);
} // functions and variables from cycript.

function setBattery(battery,timeout,count,element,elwidth){
    var calc, width, interval;
    width = 0;
    calc = Math.round((battery / 100) * elwidth);
    function animate(){
        width += count;
        document.getElementById(element).style.width = width + 'px';
        if(width >= calc){clearInterval(interval);}
    }
    interval = setInterval(animate, timeout);
}
var aniD = 0;
function details(){
    aniD += 1;
    if(aniD == 1){
        addClass(getEL('Center'),"centerdown");
        addClass(getEL('Inside1'),"showspin1");
        addClass(getEL('Inside2'),"showspin2");
        addClass(getEL('svg'),"bgcolor");
        addClass(getEL('LeftRect'),"leftrect");
        addClass(getEL('RightRect'),"rightrect");
        setTimeout(function(){getEL('detailtext').style.display="block";},1400);
        
    }
    else{
        removeClass(getEL('Center'),"centerdown");
        removeClass(getEL('Inside1'),"showspin1");
        removeClass(getEL('Inside2'),"showspin2");
        removeClass(getEL('svg'),"bgcolor");
        removeClass(getEL('LeftRect'),"leftrect");
        removeClass(getEL('RightRect'),"rightrect");
        getEL('detailtext').style.display="none";
         aniD=0;
    }
}

function init(){
    addClass(getEL('Start'),"start");
    addClass(getEL('Time'),"trightin");
    addClass(getEL('timeval'),"fadein");
    createHandler('Start',clickType,start);
    createHandler('Time',clickType,start);
 //start();

 var lastUpdate = localStorage.getItem('lastUpdate'); //get last update
    if (CT > Number(lastUpdate)) { // if current time is greater than last update plus refresh time
    UW(); //update weather
    } else {
    GW(); // get cached weather
    }

}

function start(){
    getEL('Start').style.opacity="0";
    getEL('Time').style.opacity="0";
    getEL('timeval').style.display="none";
    addClass(getEL('Bottom'),"bottomup");
    addClass(getEL('todaydiv'),'forecastfadein');
    addClass(getEL('Top'),"topdown");
    addClass(getEL('Wind'),"fadein");
    addClass(getEL('Left'),"leftin");
    addClass(getEL('Right'),"rightin");
    addClass(getEL('Center'),"center");
    addClass(getEL('Unlock'),"fadein");
    addClass(getEL('windval'),"fadein");
    addClass(getEL('tempval'),"fadein");
    addClass(getEL('timeval2'),"fadein");
    addClass(getEL('Arrow'),"arrow");
    setTimeout(function(){ removeClass(getEL('Arrow'),'arrow'); addClass(getEL('Arrow'),WD); }, 2200);
    createHandler('Right',clickType,aniright);
    createHandler('Left',clickType,anileft);
    createHandler('Unlock',clickType,unlock);
    createHandler('Center',clickType,details);

}

var aniR = 0;
function aniright(){
aniR += 1;
    if(aniR === 1){
        addClass(getEL('forecast'),"forecastfadein");
        addClass(getEL('Right'),"rightdown");
        addClass(getEL('RightExp'),"rightexpin");
        addClass(getEL('svg'),"bgcolor");
    }
    else{
        removeClass(getEL('forecast'),"forecastfadein");
        removeClass(getEL('svg'),"bgcolor");
        removeClass(getEL('Right'),"rightdown");
        removeClass(getEL('RightExp'),"rightexpin");
        addClass(getEL('Right'),"rightin");
        aniR = 0;
    }
}
var aniL = 0;
function anileft(){
aniL += 1;
    if(aniL === 1){
        addClass(getEL('Left'),"leftdown");
        addClass(getEL('LeftExp'),"leftexpin");
        addClass(getEL('svg'),"bgcolor");
        document.getElementById('percent').innerHTML = getBattery() + "%";
        document.getElementById('charging').innerHTML = getBattStat();

    setTimeout(function(){
        getEL('LBattery').style.display = "block";
        getEL('battterystat').style.display = "block";
        setBattery(getBattery(),30,3,'inner',120);
    },800);

    }
    else{
        removeClass(getEL('svg'),"bgcolor");
        removeClass(getEL('Left'),"leftdown");
        removeClass(getEL('LeftExp'),"leftexpin");
        addClass(getEL('Left'),"leftin");
        getEL('LBattery').style.display = "none";
        getEL('battterystat').style.display = "none";
        aniL = 0;
    }
}