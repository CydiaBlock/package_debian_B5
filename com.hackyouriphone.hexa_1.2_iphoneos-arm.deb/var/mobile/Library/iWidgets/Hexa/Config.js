var Scale = "1"; 
var Clock = "24h"; // choose between "12h" or "24h"
var Lang = "en"; 
var refreshrate = 10; // update interval of weather, in minutes
var IconWeather = "1"; // 1=White, 2=Black
var HourColor = "brown"; 
var MinuteColor = "gold"; 
var TextColor = "azure"; 
var BackgroundColor = "#333343"; 
var BlurBackground = true; 
var HideBackground = false; 
var HexagonColor = "brown, gold"; // Gradient (must be two colors)
var HexagonShadowColor = "gold"; 
var BlendMode = false; // Blend color text in Hexagon 
