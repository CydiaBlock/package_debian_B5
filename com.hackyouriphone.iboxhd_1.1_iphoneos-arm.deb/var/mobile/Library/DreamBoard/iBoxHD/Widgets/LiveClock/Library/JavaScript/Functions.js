function onLoad() {
	timeLoad();
	setTimeout("document.getElementById('UserWall').style.opacity=1;", 1000)
}

function timeLoad() {
	calendar = new Date();
	day = calendar.getDay();
	month = calendar.getMonth();
	date = calendar.getDate();
	year = calendar.getYear();
	hour = calendar.getHours();
	mins = calendar.getMinutes();
	secs = calendar.getSeconds();
	ampm = "PM";
	if (hour >=13){
		hour = calendar.getHours() - 12;
	} else {
		hour = calendar.getHours();
	}
	if (calendar.getHours() <=12){
		ampm = "AM"
	} else {
		ampm = "PM"
	}
	var dayname = new Array ("", "", "", "", "", "", "");
	var monthname = new Array ("","","","","","","","","","","","" );
	if (secs <=9){
		secs = "0" + secs
	}
	
	if (mins <=9){
		mins = "0" + mins
	}
	
	if (year < 1000)
	year+=1900
	cent = parseInt(year/100);
	g = year % 19;
	k = parseInt((cent - 17)/25);
	i = (cent - parseInt(cent/4) - parseInt((cent - k)/3) + 19*g + 15) % 30;
	i = i - parseInt(i/28)*(1 - parseInt(i/28)*parseInt(29/(i+1))*parseInt((21-g)/11));
	j = (year + parseInt(year/4) + i + 2 - cent + parseInt(cent/4)) % 7;
	l = i - j;
	emonth = 3 + parseInt((l + 40)/44);
	edate = l + 28 - 31*parseInt((emonth/4));
	emonth--;
	if (date< 10) date = "0" + date;
	document.getElementById("calendarBar").innerHTML = monthname[month] + " " + date;
	document.getElementById("timeBar").innerHTML = hour + ":" + mins;
	document.getElementById("dayBar").innerHTML = dayname[day];
	setTimeout("timeLoad()", 1000) 
	
}
