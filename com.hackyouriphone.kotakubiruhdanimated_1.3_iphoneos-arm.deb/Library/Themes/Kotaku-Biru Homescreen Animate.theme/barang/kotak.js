function mukadimah(){
	var cssAnimation = document.createElement('style');
	cssAnimation.type = 'text/css';
	var rules = document.createTextNode('@-webkit-keyframes rolljauh {0% {top:'+document.body.offsetHeight+'px;-webkit-transform: rotate(0deg)}'+
		'100%{top:-50px;-webkit-transform: rotate(360deg)}}'+
		'@-webkit-keyframes rollmid {0% {top:'+document.body.offsetHeight+'px;-webkit-transform: rotate(0deg)}'+
		'100%{top:-120px;-webkit-transform: rotate(360deg)}}'+
		'@-webkit-keyframes rolldekat {0%{top:'+document.body.offsetHeight+'px;-webkit-transform: rotate(0deg)}'+
		'100%{top:-140px;-webkit-transform: rotate(-360deg)}}'+
		'.jauh1, .jauh2, .jauh3, .jauh4, .jauh5, .jauh6{top:'+document.body.offsetHeight+'px;-webkit-animation: rolljauh 25s linear infinite;}'+
		'.mid1, .mid2, .mid3{top:'+document.body.offsetHeight+'px;-webkit-animation: rollmid 18s linear infinite;}'+
		'.dekat1, .dekat2, .dekat3{top:'+document.body.offsetHeight+'px;-webkit-animation: rolldekat 8s linear infinite;}'
	);

	cssAnimation.appendChild(rules);
	document.getElementsByTagName("head")[0].appendChild(cssAnimation);
}
