
window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);


var remin = '';
var even = '';
var natu = 'Loading';
var bat = '';
var count = 0;


function init(){
	checkSettings();
	if(ti === 1){
		updateClock();
		setInterval("updateClock();", 1000);
	}
	
	//animate(document.getElementById("_menu"));
	if(notif === 1){
		animate(document.getElementById("_noti"), 2, 0);
	}
	
	if(bg === 0){
		document.getElementById("_bg").style.display = 'none';
	}
	
	if(showInfo === 1){
		changeInfo();
	}else{
		document.getElementById("_info").style.display = 'none';
	}
}


function checkSettings(){
	
	if(ti === 0){
		document.getElementById("_time").style.display = 'none';
		document.getElementById("_date").style.display = 'none';
	}
	
	if(oldTime === 1){
		document.getElementById('_time').classList.remove('small');
		document.getElementById('_date').classList.remove('small');
		document.getElementById('_time').classList.add('big');
		document.getElementById('_date').classList.add('big');
	}
	
	if(isClassic === 1){
		document.getElementById('_menu').style.top = '75vh';
		
		if(oldTime === 1){
			document.getElementById('_noti').style.top = '180px';
		}else{
			document.getElementById('_noti').style.top = '120px';
		}
		document.getElementById('_noti').style.left = '50%';
		document.getElementById('_noti').style.transform = 'translateX(-50%)';
		
		document.getElementById('_back').style.top = '75vh';
		
		document.getElementById('_app11').style.display = 'none';
		document.getElementById('_app12').style.display = 'none';
		document.getElementById('_app13').style.display = 'none';
		document.getElementById('_app14').style.display = 'none';
	}
	
	checkUsage();
	
	document.getElementById("_app1Txt").innerHTML = ap1N;
	document.getElementById("_app2Txt").innerHTML = ap2N;
	document.getElementById("_app3Txt").innerHTML = ap7N;
	document.getElementById("_app4Txt").innerHTML = ap3N;
	document.getElementById("_app5Txt").innerHTML = ap4N;
	document.getElementById("_app6Txt").innerHTML = ap5N;
	document.getElementById("_app7Txt").innerHTML = ap6N;
	document.getElementById("_app8Txt").innerHTML = ap8N;
	document.getElementById("_app9Txt").innerHTML = ap9N;
	document.getElementById("_app10Txt").innerHTML = ap10N;
	document.getElementById("_app11Txt").innerHTML = ap11N;
	document.getElementById("_app12Txt").innerHTML = ap12N;
	document.getElementById("_app13Txt").innerHTML = ap13N;
	document.getElementById("_app14Txt").innerHTML = ap14N;
	
}


//------------------------- TIME FUNCTIONS ---------------------------
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	//var Time24 = 1;
	
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
		currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
		currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	}
	
	
	//document.getElementById("_month").innerHTML = shortmonths[currentTime.getMonth()];
	//document.getElementById("_day").innerHTML = days[currentTime.getDay()];
	document.getElementById("_date").innerHTML = (currentTime.getMonth() + 1) + "." + currentDate + "." + currentYear;
	
	document.getElementById("_time").innerHTML = currentHours + ":" + currentMinutes1;
	//document.getElementById("_minutes").innerHTML = currentMinutes1;
		
}


//------------------------- BUTTONS FUNCTIONS ---------------------------
function openMenu(){
	TweenMax.to(document.getElementById("timeCont"), 0.5, {alpha:0, onComplete:function(){
		document.getElementById("timeCont").style.display = 'none';
		document.getElementById("menuCont").style.display = 'block';
		document.getElementById("menuCont").style.opacity = 0;
		TweenMax.to(document.getElementById("menuCont"), 0.5, {alpha:1});
	}});
}

function closeMenu(){
	TweenMax.to(document.getElementById("menuCont"), 0.5, {alpha:0, onComplete:function(){
		document.getElementById("menuCont").style.display = 'none';
		document.getElementById("timeCont").style.display = 'block';
		document.getElementById("timeCont").style.opacity = 0;
		TweenMax.to(document.getElementById("timeCont"), 0.5, {alpha:1});
	}});
}

function openApp(app, num){
	window.location = 'xeninfo:openapp:' + app;
	
	if(showUsage === 1){
		usage(num);
	}
}

function changeColor(){
	if(document.getElementById("_color").classList.contains("black")){
		document.getElementById("_color").classList.remove("black");
		document.getElementById("_color").classList.remove("light");
		document.getElementById("_color").classList.add("dark");
		document.documentElement.style.setProperty('--primary', '#C7D4E6');
		document.documentElement.style.setProperty('--secondary', '#22252E');//#1F2731
		document.documentElement.style.setProperty('--third', '#878F99');
		
		document.getElementById("_color").innerHTML = 'dark';
		return;
	}
	
	if(document.getElementById("_color").classList.contains("dark")){
		document.getElementById("_color").classList.remove("black");
		document.getElementById("_color").classList.remove("dark");
		document.getElementById("_color").classList.add("light");
		document.documentElement.style.setProperty('--primary', '#878F99');
		document.documentElement.style.setProperty('--secondary', '#DFDFDF');
		document.documentElement.style.setProperty('--third', '#717171');
		
		document.getElementById("_color").innerHTML = 'light';
		return;
	}
	
	if(document.getElementById("_color").classList.contains("light")){
		document.getElementById("_color").classList.remove("light");
		document.getElementById("_color").classList.remove("dark");
		document.getElementById("_color").classList.add("black");
		document.documentElement.style.setProperty('--primary', '#FFFFFF');
		document.documentElement.style.setProperty('--secondary', '#000000');
		document.documentElement.style.setProperty('--third', '#878F99');
		
		document.getElementById("_color").innerHTML = 'black';
		return;
	}
}


//------------------------- XENINFO FUNCTIONS ---------------------------
function mainUpdate(type){ 
	if (type == "system"){
		checkNoti();		
	}else if(type === "weather"){
		natu = weather.naturalCondition;
		document.getElementById('tempe').innerHTML = weather.temperature + "º" + " - " + weather.condition;
	}else if (type === "battery"){
		checkBattery();
	}else if (type === "music"){
		checkMusic();
	}else if(type == "reminders"){
		checkRem();
    }else if(type == "events"){
		checkEvent();
    }
}

function checkBattery(){
	if(batteryCharging === 1){
		document.getElementById("percent").innerHTML = 100 - batteryPercent + "% to full"; 
		bat = batteryPercent + "% - charging";
		if(batteryPercent === 100){
			document.getElementById("percent").innerHTML = batteryPercent + "% unplug";
			bat = batteryPercent + "% unplug";
		}
		document.getElementById("particles-js").style.display = 'block';
	}else{
		document.getElementById("percent").innerHTML = batteryPercent + "% Left"; 
		bat = batteryPercent + "% - discharging"; 
		document.getElementById("particles-js").style.display = 'none';	
	}
}

//------------------------- REMINDERS FUNCTIONS ---------------------------
function checkRem(){
	if(reminders.length > 0){
		if(showRE){
			document.getElementById('_rem').innerHTML = reminders.length;
		}
		remin = '';
	}else{
		if(showRE){
			document.getElementById('_rem').innerHTML = '0';
		}
		remin = 'No Reminders';
	}
    for (var i = 0; i < reminders.length; i++) {
        remin += reminders[i].title + " - " + reminders[i].dueDate + "</br>";
    }
}

//------------------------- EVENTS FUNCTIONS ---------------------------
function checkEvent(){
	if(events.length > 0){
		if(showRE){
			document.getElementById('_eve').innerHTML = events.length;
		}
		even = '';
	}else{
		if(showRE){
			document.getElementById('_eve').innerHTML = '0';
		}
		even = 'No Events';
	}
    for (var i = 0; i < events.length; i++) {
        even += events[i].title + " - " + events[i].date + "</br>";
    }
}


function checkNoti(){
	if(notif === 1){
		if(notificationShowing === 'yes'){
			document.getElementById("_noti").style.display = 'block';
		}else{
			document.getElementById("_noti").style.display = 'none';
		}
	}
}

//--------------------------- ANIMATIONS --------------------------
function animate(obj, time = 10, al = 0.4){
	TweenMax.to(obj, time, {alpha:al, onComplete:function(){
		TweenMax.to(obj, time, {alpha:1, onComplete:function(){
			animate(obj, time, al)
		}});
	}});
}

function changeInfo(){
	
	if(count > 3){
		count = 0;
	}
	
	if(count === 0){
		document.getElementById("_infoTxt").innerHTML = natu;
	}
	if(count === 1){
		document.getElementById("_infoTxt").innerHTML = remin;
	}
	if(count === 2){
		document.getElementById("_infoTxt").innerHTML = even;
	}
	if(count === 3){
		document.getElementById("_infoTxt").innerHTML = bat;
	}
	
	TweenMax.to(document.getElementById("_infoTxt"), 0.5, {alpha:1, onComplete:function(){
		TweenMax.to(document.getElementById("_infoTxt"), 5, {onComplete:function(){
			TweenMax.to(document.getElementById("_infoTxt"), 1, {alpha:0, onComplete:function(){
				count++;
				changeInfo();
			}});
		}});
	}});
}


