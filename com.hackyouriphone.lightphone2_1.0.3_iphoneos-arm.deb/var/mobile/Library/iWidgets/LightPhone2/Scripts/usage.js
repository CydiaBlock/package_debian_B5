// every app alpha change with percentage usage
// apps percentage based on taps
// total taps to calculate total percentage
// taps per app
// max alpha 0.5 min alpha 0.2

var appTaps = [0,0,0,0,0,0,0,0,0,0,0,0,0,0];
var appPer = [0,0,0,0,0,0,0,0,0,0,0,0,0,0];
var appNa = ["_app1","_app2","_app3","_app4","_app5","_app6","_app7","_app8","_app9","_app10","_app11","_app12","_app13","_app14"];
var tTaps = 0;


function checkUsage(){
	if(showUsage === 0){
		for(var i=0; i<appNa.length; i++){
			document.getElementById(appNa[i] + "U").style.display = 'none';
			document.getElementById(appNa[i] + "Bg").style.opacity = 0.2;
		}
	}
}

function usage(num){
	tTaps++;
	appTaps[num] = appTaps[num] + 1;
	
	for(var i=0; i<appPer.length; i++){
		appPer[i] = appTaps[i] * 100 / tTaps;
		var alp = appPer[i] * 0.5 / 100;
		if(alp < 0.1){
			alp = 0.1;
		}
		if(alp > 0.5){
			alp = 0.5;
		}
		document.getElementById(appNa[i] + "Bg").style.opacity = alp;
		document.getElementById(appNa[i] + "U").innerHTML = appPer[i].toFixed(0) + '%';
	}
}

