function convertAlarm(time, type, addAmPm) {
    var atod,
        hourSplit = time.split(':')[0],
        minuteSplit = time.split(':')[1];
    if (type == '12') {
        atod = 'am';
        if (hourSplit > 12) {
            nhour = hourSplit - 12;
            atod = 'pm';
        } else {
            nhour = hourSplit;
        }
        if (addAmPm) {
            return nhour + ":" + ((Number(minuteSplit) < 10) ? ((minuteSplit === '00') ? minuteSplit : '0' + minuteSplit) : minuteSplit) + atod;
        } else {
            return nhour + ":" + ((Number(minuteSplit) < 10) ? ((minuteSplit === '00') ? minuteSplit : '0' + minuteSplit) : minuteSplit);
        }
    } else {
        return (time == '0:00' ? time : time.split(':')[0] + ':' + ((minuteSplit < 10) ? '0' + minuteSplit : minuteSplit));
    }
}
function getiOSAlarm(scheduledAlarm){
    if (scheduledAlarm[0]) {
        return scheduledAlarm[0].userInfo.hour + ":" + scheduledAlarm[0].userInfo.minute;
    } else {
        return "0:00";
    }
}
function checkFirmware(point) {
    var iOS = cycript.firmware.split('.'),
        firstDigit = Number(iOS[0]);
    if (point == 'secondDigit') {
        if(iOS[1]){
          return iOS[1];
        }else{
          return 0;
        }
    } else {
        if (firstDigit <= 7) {
            return 'iOS7';
        } else {
            if (firstDigit == 8) {
                return "iOS8";
            }
            if (firstDigit == 9) {
                return "iOS9";
            }
        }
    }
}
var intervalCount = 0;
function waitUnlock(url){
    intervalCount ++
   if(cycript.isLocked() == false){
    clearInterval(window.interval);
    cycript.openNSURL(url);
   }
   if(intervalCount >= 10){
    clearInterval(window.interval);
    intervalCount = 0;
   }
}
function openURL(url){
  if(cycript.passcodeOn){
    cycript.unlockPhone();
    window.interval = window.setInterval(function(){
      waitUnlock(url);
    }, 1000);
  }else{
    cycript.openNSURL(url);
  }
}
function waitAppUnlock(bundle){
  intervalCount ++
   if(cycript.isLocked() == false){
    clearInterval(window.appinterval);
    cycript.openApplicationForce(bundle);
   }
   if(intervalCount >= 10){
        clearInterval(window.appinterval);
        intervalCount = 0;
     }
}
function openApp(bundle){
  if(cycript.passcodeOn){
   cycript.unlockPhone();
    window.appinterval = window.setInterval(function(){
      waitAppUnlock(bundle);
    }, 1000);
  }else{
    try{
    cycript.openApplication(bundle);
  }catch(err){alert(err)}
  }
}
function getCharging(){
  var ischarging = cycript.chargeStatus;
  if(ischarging){
    return 'Charging';
  }
  return 'Not Charging';
}
function getisCharging(){
  var ischarging = cycript.chargeStatus;
  if(ischarging){
    return 'Charging';
  }
  return ' ';
}
function folderExists(folder){
    if(localStorage.LockPlus !== 'exists'){
        cycript.checkFolder(folder);
    }
}
function saveURL(url){
  //action.showLoader(true);
  cycript.cancelTimer();
  folderExists('LockPlus');
  var name = url;
  url = url.replace(/ /g,"%20");
  url = 'http://lockplus.us/php/themes/'+url+'.plist';
  try{
  var urlData = cycript.urlData(url);
}catch(err){
  alert(err);
}
  if(urlData){
    var filePath = 'var/mobile/Library/LockPlus/'+name+'.plist';
    cycript.writeFile(urlData,filePath);
    action.showLoader(false);
    action.loadTheme(name);
  }else{
    action.showLoader(false);
    alert('There is no theme ' + name + ' OR the server is currently down.');
  }
  url = null;
  urlData = null;
}


