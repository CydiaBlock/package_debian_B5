function loadInfo() {
    var background = document.createElement('div'),
        p0,
        p1,
        p2,
        p3,
        instruct,
        themeInfo,
        trashcan,
        info1,
        info2;
    background.className = 'darkbg';
    instruct = document.createElement('div');
    instruct.className = 'instruct';

    p0 = document.createElement('p');
    p0.innerHTML = "-Swipe Image-";

    p1 = document.createElement('p');
    p1.className = 'psmall';
    p1.innerHTML = "Down to close";

    p2 = document.createElement('p');
    p2.className = 'psmall';
    p2.innerHTML = "Up to load";

    p3 = document.createElement('p');
    p3.className = 'psmall';
    p3.innerHTML = "Left/Right for themes";

    instruct.appendChild(p0);
    instruct.appendChild(p1);
    instruct.appendChild(p2);
    instruct.appendChild(p3);

    background.appendChild(instruct);
    document.getElementById('mainContainer').appendChild(background);


    themeInfo = document.createElement('div');
    themeInfo.className = 'themeList';

    info1 = document.createElement('p');
    info1.className = 'themeName';

    info2 = document.createElement('p');
    info2.className = 'themeCount';

    themeInfo.appendChild(info1);
    themeInfo.appendChild(info2);
    document.getElementById('mainContainer').appendChild(themeInfo);

    trashcan = document.createElement('div');
    trashcan.id = "trash";
    trashcan.innerHTML = '<img onclick="deleteTheme()" src="svg/trash.svg"/>';
    trashcan.style.display = 'none';
    document.getElementById('mainContainer').appendChild(trashcan);
}

var displayThemeList = function() {
    loadInfo();
    var dict = cycript.readDict('var/mobile/Library/LockPlus/' + action.themeList[action.themePosition]),
        tPrev = dict.ThemePreview,
        tName = dict.ThemeName,
        cName = dict.DevName;
    document.querySelector('.themeList').style.backgroundImage = 'url(' + tPrev + ')';
    document.querySelector('.themeName').innerHTML = tName + ' by: ' + cName;
    document.querySelector('.themeList').style.display = 'block';
    document.querySelector('.darkbg').style.display = 'block';
    document.querySelector('.themeCount').innerHTML = (action.themePosition + 1) + '/' + action.themeList.length;
    document.getElementById('trash').style.display = 'block';
    dict = null;
};

var saveTheme = function() {
    try {
        var dict = cycript.readDict('var/mobile/Library/LockPlus/' + action.themeList[action.themePosition]);
        if (dict.Wallpaper.length > 10) {
            if (!options.disablewall) {
                var img = dict.Wallpaper.split(',')[1].replace(/[()]/g,'');
            cycript.setLSWall(img, 2);
            if (options.setsbwall) {
                cycript.setLSWall(img,1);
            }
            }
        }
        action.savedElements.overlay = dict.Overlay;
        if (dict.Elements.length > 10) {
            action.savedElements.placedElements = JSON.parse(dict.Elements);
        } else {
            action.savedElements.placedElements = '';
        }
        if (dict.IconName.length > 2) {
            action.savedElements.iconName = dict.IconName;
        } else {
            action.savedElements.iconName = 'simply';
        }
        localStorage.setItem('placedElements', JSON.stringify(action.savedElements));
        dict = null;
        window.location = location.href;
    } catch (err) {
    }
};

var switchThemes = function(direction) {
    if (direction === 'r') {
        if (action.themePosition <= 0) {
            action.themePosition = action.themeList.length - 1;
        } else {
            action.themePosition = action.themePosition - 1;
        }
        displayThemeList();
    } else if (direction === 'l') {
        if (action.themePosition + 1 >= action.themeList.length) {
            action.themePosition = 0;
        } else {
            action.themePosition = action.themePosition + 1;
        }
        displayThemeList();
    } else if (direction === 'u') {
        jsSwipes.themeOpened = false;
        document.getElementById('trash').style.display = 'none';
        document.querySelector('.darkbg').style.display = 'none';
        document.querySelector('.themeList').style.webkitTransition = 'all .3s ease-in-out';
        document.querySelector('.themeList').style.webkitTransform = 'translateX(-50%)translateY(-50%)scale(4)';
        document.querySelector('.themeList').style.opacity = '0';
        document.querySelector('.darkbg').innerHTML = "";
        setTimeout(function() {
            saveTheme();
        }, 310);
    } else if (direction === 'd') {
        jsSwipes.themeOpened = false;
        document.querySelector('.themeList').style.display = 'none';
        document.querySelector('.darkbg').style.display = 'none';
        document.getElementById('trash').style.display = 'none';
        action.themePosition = 0;
        action.themeList = [];
    }
};

var populateThemeList = function() {
    folderExists('LockPlus');
    var folderContents = cycript.readFolder('var/mobile/Library/LockPlus'),
        i;
    if (folderContents.length <= 0) {
        window.alert('You have no themes saved:(');
    } else {
        for (i = 0; i < folderContents.length; i += 1) {
            if (folderContents[i].substring(folderContents[i].length - 6, folderContents[i].length) === '.plist') {
                action.themeList.push(String(folderContents[i]));
            }
        }
        displayThemeList();
        if (!jsSwipes.swipeEnabled) {
            detectswipe('.themeList', switchThemes);
            jsSwipes.swipeEnabled = true;
        }
    }
};

try {
    populateThemeList();
} catch (err) {
    try{
        //maybe user deleted var/mobile/Library/LockPlus folder
        localStorage.LockPlus = null;
        folderExists('LockPlus');
        populateThemeList();
    }catch(err){
        alert(err);
    }
}





