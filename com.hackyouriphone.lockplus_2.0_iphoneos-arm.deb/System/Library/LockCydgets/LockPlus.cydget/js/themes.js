var baseStart = 0;
var baseEnd = 21;
var amountToLoad = 21;
var page = 1;

var makeFrame = document.createElement('div');
makeFrame.id = 'frame';
document.body.appendChild(makeFrame);

function loadPage(themecount, themeStart) {
    var firstCount, lastCount;
    if (themeStart) {
        if (themeStart == 'next') {
            firstCount = baseStart + amountToLoad;
            lastCount = (baseEnd + amountToLoad > theme_array.length) ? theme_array.length : baseEnd + amountToLoad;
            if (firstCount > theme_array.length - amountToLoad) {
                firstCount = 0;
                lastCount = 21;
                page = 0;
            }
            baseStart = firstCount;
            baseEnd = lastCount;
            page = page + 1;
        } else if (themeStart === 'prev') {
            firstCount = (baseStart - amountToLoad < 0) ? 0 : baseStart - amountToLoad;
            lastCount = (baseEnd - amountToLoad < 1) ? amountToLoad : baseEnd - amountToLoad;
            baseStart = firstCount;
            baseEnd = lastCount;
            page = (page - 1 < 1) ? 1 : page - 1;
        }
    } else {
        firstCount = 0;
        lastCount = amountToLoad;
        page = 1;
    }
    var frames = document.getElementById('frame');
    var fragment = document.createDocumentFragment();
    for (var i = firstCount; i < lastCount; i++) {
        var themeHolder = document.createElement('div');
        themeHolder.className = 'themeContainer';
        var img = document.createElement('img');
        img.className = 'themeimg';
        img.title = theme_array[i];
        img.src = 'http://LockPlus.info/themes/themepreview/' + theme_array[i] + '.jpg';
        var nTheme = action.newThemes.indexOf(theme_array[i]);
        if (nTheme !== -1) {
            var newImage = document.createElement('img');
            newImage.src = 'svg/newbadge.png';
            newImage.className = 'themebadge';
            themeHolder.appendChild(newImage);
        }
        themeHolder.appendChild(img);
        fragment.appendChild(themeHolder);
    }
    var buttons = document.createElement('div');
    buttons.className = "buttons"
    buttons.id = 'buttons';
    var next = document.createElement('div');
    var prev = document.createElement('div');
    var pages = document.createElement('div');
    pages.innerHTML = "Page " + page;
    pages.className = 'pagesCount';
    next.innerHTML = "next";
    next.id = "nextButton";
    next.className = "nextButton";
    prev.innerHTML = "prev";
    prev.id = "prevButton";
    prev.className = "prevButton";
    buttons.appendChild(next);
    buttons.appendChild(prev);
    buttons.appendChild(pages);
    frames.appendChild(fragment);
    frames.appendChild(buttons);
    document.getElementById('frame').style.display = 'block';
}

function clearThemePreviews() {
    var frames = document.getElementById('frame');
    frames.scrollTop = 0;
    while (frames.hasChildNodes()) {
        frames.removeChild(frames.lastChild);
    }
}

document.getElementById('frame').addEventListener('click', function(el) {
    clearThemePreviews();
    if (el.target.id === "nextButton" || el.target.id === "prevButton") {
        if (el.target.id === "nextButton") {
            loadPage(theme_array.length, 'next');
        } else if (el.target.id === "prevButton") {
            loadPage(theme_array.length, 'prev');
        }
    } else if (el.target.id === 'buttons') {

        var div = document.getElementById("frame");
            div.parentNode.removeChild(div);
    } else {
        action.showLoader(true);
        setTimeout(function() {
            saveURL(el.target.title);
        }, 300);
    }
});