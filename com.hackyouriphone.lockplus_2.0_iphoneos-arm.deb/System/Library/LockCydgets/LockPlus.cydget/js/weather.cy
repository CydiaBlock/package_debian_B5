function updateWeather() {
  if(cycript.locationService){
    WPref = [WeatherPreferences sharedPreferences]; //all firmwares
    WLocation = [WeatherLocationManager sharedWeatherLocationManager]; //all firmwares
    WCity = [WPref localWeatherCity]; // allfirmwares
    if(checkFirmware() === "iOS7"){
      LUpdate = [WeatherLocationManager sharedWeatherLocationManager]; //iOS7
    }else{
      LUpdate = [TWCLocationUpdater sharedLocationUpdater]; //iOS8 and iOS9
    }
    [WLocation setDelegate:[[CLLocationManager alloc] init]]; //all firmwares
    if(checkFirmware() === "iOS8" || checkFirmware() === "iOS9"){
      if(checkFirmware() === "iOS8" && checkFirmware('secondDigit') < 3){
          [WLocation setLocationTrackingReady:YES activelyTracking:NO]; //iOS 8.0, 8.1, and 8.2 only
       }else{
          if(checkFirmware() === "iOS7"){
            [WLocation setLocationTrackingReady:YES activelyTracking:NO];
          }else{
            [WLocation setLocationTrackingReady:YES activelyTracking:NO watchKitExtension:NO]; //iOS 8.3
          }
       }
    }else if(checkFirmware() === "iOS7"){
      [WLocation setLocationTrackingReady:YES activelyTracking:NO];
    }
    [WLocation setLocationTrackingActive:YES]; //all firmwares
    [WPref setLocalWeatherEnabled:YES]; //all firmwares
    if(checkFirmware() === "iOS7"){
      [[LocationUpdater sharedLocationUpdater] updateWeatherForLocation:[WLocation location] city:WCity]; //iOS7
      [[LocationUpdater sharedLocationUpdater] handleCompletionForCity:WCity withUpdateDetail:0]; //iOS7
    }else{
      [LUpdate updateWeatherForLocation:[WLocation location] city:WCity]; //iOS8 and iOS9
      [LUpdate handleCompletionForCity:WCity withUpdateDetail:0]; //iOS8 and iOS9
    }
  }else{
        //alert("Enable Location Services");
  }
}