// WIDGET WEATHER v3 BASE - FULL and SIMPLE //
// Design by Boots, NewD & Marty McFly
// Includes codework by Dacal, Ian Nicoll, The_Durben & Simon//

// Official support thread on ModMyi can be found here (copy and paste to your browser) http://modmyi.com/forums/file-mods/849520-widgetweather-3-0-our-finest-hour.html

// -----CONFIGURATION OPTIONS-----//
var lang = "en";

/*  LANGUAGE OPTIONS:
(no) for Norweigan
(it) for Italian
(fi) for Finland
(nl) for Dutch
(fr) for french
(ge) for german
(sp) for spanish
(cn) for Chinese
(ru) for Russian
(en) or for english

Moon Phase descriptions and Wind Direction text are NOT translated. Everything else is. 

For proper auto sizing of weather icons on iPad - take note of 3 sections of code to enable in the main.js' dealWithWeather () function
*/

//var Wallpaper_options = "userwall";	// weatherwalls, daynightwalls, userwall ////If you want to control here - take this code line out of head of the html

//var numberOfForcastDays = 5;	//1,2,3,4 or 5 //If you want to control here - take line this code line out of head of the html

var UseExtraLocation = "auto";	//choose "city" or "neighborhood" or "auto"

var iconSet = "iDidit2";	// Name of the folder in Icon Sets you want to use

var GMT =  0;				// Adjust sunrise sunset times if yahoo reports incorrectly for your location

var mainInfo = "DEFAULT"; //Choose main Weather source for showing Description, Temp and High/Low in upper section of widget
//"ACCU" = Accuweather USA -color code: #B6A1AF
//"YAHOO" = Yahoo -color code: #8B776C
//"FIO" = Forecast.io -color code: #A19E8B
//"WU" = WeatherUnderground -color code: #768A95
//"DEFAULT" = Weather.com - Apple's weather info - #FOECE9