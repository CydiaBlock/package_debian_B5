var ShowAnimation = true;
var ShowWidget = true;
var TextColor = "White";
var TextAlignment = "Right";
var FromBottom = 20;
var FromRight = 20;
var TwentyFourHourTime = false;
