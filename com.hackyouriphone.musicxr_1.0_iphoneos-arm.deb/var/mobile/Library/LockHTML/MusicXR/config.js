var ActivationBGColor = "darkred"; 
var ActivationTextColor = "White"; 
var ActivationLeft = true; 
var InvertPlayer = true; 
var ActivationSize = 100; // In Percent
var PlayerSize = 100; // In Percent
