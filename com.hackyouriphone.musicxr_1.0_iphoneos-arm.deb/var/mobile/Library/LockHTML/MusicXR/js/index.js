$('.ani_class').on("click", function() {
	console.log("Clicked");
	$('.music_container').slideToggle( 1000, function() {
		$('.music_container_inner').show( 100 );
	});
});
