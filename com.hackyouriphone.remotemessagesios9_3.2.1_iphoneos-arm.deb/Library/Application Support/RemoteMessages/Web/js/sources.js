/*!
 * Remote Messages v3.1
 * Data Sources
 * Copyright (c) 2014 Beast Soft - http://beastsoft.co.uk/
 */
var availableSettings = "/settings.json";
var conversations = "./getInitialContactList.srv";
var messages = "./getMessages.srv";
var sending = "./sendMessage.srv";
var contacts = "./contacts.srv";
var confirmReceiveURL = "./confirmMsgRead.srv";
var loadLimit = "./incrementMessageLoadLimit.srv";
var resending = "./resendMessage.srv";
var deletion = "./deleteMessagePart.srv";
var deleteConversation = "./deleteConversation.srv";
var phoneStatusURL = "./getPhoneStatus.srv";
var getAllSettings = "./getAllSettings.srv";
var setSettings  = "./setSettings.srv";
var getInstalledThemes = "./getInstalledThemes.srv";
var getGalleryList = "./getGalleryList.srv";