/*
var ShowLocations = false;  //Set to true shows team names as cities
var ampm = true;
var lang = "en";
var updateInterval = 1;
*/