var iPhoneType = "auto";
var Sport = "nhl";

var iOS = navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false;
if (iOS == true) { var touchmode = "touchend"; } else { var touchmode = "click"; }


// GET THE CURRENT WIDTH & HEIGHT
if (iPhoneType == "auto") {
	if (screen.height == 480) { iPhoneType = "iPh4"; }
	else if (screen.height == 568) { iPhoneType = "iPh5"; }
	else if (screen.height == 667) { iPhoneType = "iPh6"; }
	else { iPhoneType = "iPh6Plus"; }
}

// RESIZE THE BODY
window.addEventListener("load", function() { 
	switch(iPhoneType) {
		case "iPh4":
			document.body.style.width='320px';
    		document.body.style.height='568px'; // Keep at 568px (not 480px).
		break;
		case "iPh5":
			document.body.style.width='320px';
    		document.body.style.height='568px';
		break;
		case "iPh6":
			document.body.style.width='375px';
    		document.body.style.height='667px';
		break;
		case "iPh6Plus":
			document.body.style.width='414px';
    		document.body.style.height='736px';
		break;
	}
}, false);

 function init ( ) {

	document.getElementById("NoGames").style.display = "none";
	
 	document.getElementById("TouchNHL").addEventListener(touchmode, touchRefresh, false);
	function touchRefresh() {
		event.preventDefault();
		Sport = "nhl";
		getscores();
	}
	
	document.getElementById("TouchMLB").addEventListener(touchmode, touchRefresh1, false);
	function touchRefresh1() {
		event.preventDefault();
		Sport = "mlb";
		getscores();
	}
	
  	document.getElementById("TouchNBA").addEventListener(touchmode, touchRefresh2, false);
	function touchRefresh2() {
		event.preventDefault();
		Sport = "nba";
		getscores();
	}
	
	document.getElementById("TouchNFL").addEventListener(touchmode, touchRefresh3, false);
	function touchRefresh3() {
		event.preventDefault();
		Sport = "nfl";
		getscores();
 	}
 
 getscores();
 setInterval(getscores, updateInterval*60*1000);
 setInterval(updateClock, 1000);
 }
 
function updateClock() {
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
	var currentDate = currentTime.getDate() < 10 ? '' + currentTime.getDate() : currentTime.getDate();
	timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
	
	if (ampm == false) {
		timeOfDay = "";
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentTimeString = currentHours + ":" + currentMinutes;
	} else {
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
//		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentTimeString = currentHours + ":" + currentMinutes;
	}
	
	document.getElementById("clock").innerHTML = currentTimeString+timeOfDay;
	document.getElementById("date").innerHTML = days[currentTime.getDay()] + ", " + months[currentTime.getMonth()] + " " + currentDate;	
}

function getscores(){
	 document.getElementById("background").src = "Images/BG-" + Sport + ".jpg";
	 document.getElementById("offline").style.display = "none"; 
	 
var url = "http://scores.espn.go.com/allsports/scorecenter/v3/events?sport=" + Sport;

	$.getJSON(url, function(data) {
	
				TeamNameA = new Array;
				TeamNameB = new Array;
				TeamAScore = new Array;
				TeamBScore = new Array;
				TeamALogo = new Array;
				TeamBLogo = new Array;
				Status = new Array;
				
	if (data.contents ==""){
	document.getElementById("NoGames").style.display = "block";
	document.getElementById("NoGames").innerHTML = "No games on the roster for today";
	document.getElementById("background").style.opacity = "1.0";
	}else{
	var HowManyGames = data.contents[0].contents.length;
	document.getElementById("NoGames").style.display = "none";
	document.getElementById("background").style.opacity = "0.6";
	}
	
			var el = document.getElementById('data');
			while ( el.firstChild ) el.removeChild( el.firstChild );
					
					for (var i=0; i < (HowManyGames); i++) {
						
						if (ShowLocations ==true){
							TeamNameA[i] = data.contents[0].contents[i].competitors[0].location;
							TeamNameB[i] = data.contents[0].contents[i].competitors[1].location;
						}else{
							TeamNameA[i] = data.contents[0].contents[i].competitors[0].name;
							TeamNameB[i] = data.contents[0].contents[i].competitors[1].name;
						}
						TeamAScore[i] = data.contents[0].contents[i].competitors[0].score;
						TeamBScore[i] = data.contents[0].contents[i].competitors[1].score;
						TeamALogo[i] = data.contents[0].contents[i].competitors[0].logo.logo;
						TeamBLogo[i] = data.contents[0].contents[i].competitors[1].logo.logo;
						Status[i] = data.contents[0].contents[i].status;
						if (Status[i] == "[date]")	{Status[i]=data.contents[0].contents[i].buttons[0].link.share.text.split(" ",4).join(" ").slice(4);}			
														
						var LogoA = document.createElement('img');
						LogoA.src = "http://a.espncdn.com/combiner/i?img=/i/teamlogos/" + Sport + "/500-dark/scoreboard/"+TeamALogo[i]+".png&w=80&h=80&transparent=true";
						LogoA.id = "LogoA" + i;
						document.getElementById("data").appendChild(LogoA);
						document.getElementById("LogoA" + i).style.top = 5 +  31*(i) + "%";
						document.getElementById("LogoA" + i).className = "LogoA";
									
						var LogoB = document.createElement('img');
						LogoB.src = "http://a.espncdn.com/combiner/i?img=/i/teamlogos/" + Sport + "/500-dark/scoreboard/"+TeamBLogo[i]+".png&w=80&h=80&transparent=true";
						LogoB.id = "LogoB" + i;
						document.getElementById("data").appendChild(LogoB);
						document.getElementById("LogoB" + i).style.top = 17.5 +  31*(i) + "%";
						document.getElementById("LogoB" + i).className = "LogoB";
						
						var Status1 = document.createElement('div');
						Status1.innerHTML = Status[i];
						Status1.id = "Status" + i;
						document.getElementById("data").appendChild(Status1);
						document.getElementById("Status" + i).style.top = 10.5 +  31*(i) + "%";
						document.getElementById("Status" + i).className = "Status";
						
						var Teams = document.createElement('div');
						Teams.innerHTML = TeamNameA[i] + " " + '<span class="FontColorRed">' + TeamAScore[i] +  '</span>' + " <BR> " + TeamNameB[i] + " " + '<span class="FontColorRed">' + TeamBScore[i] + '</span>';
						Teams.id = "Teams" + i;
						document.getElementById("data").appendChild(Teams);
						document.getElementById("Teams" + i).style.top = 5.5 +  31*(i) + "%";
						document.getElementById("Teams" + i).className = "Teams";
					} 
			
	}).fail(function() {
			document.getElementById("offline").style.display = "block"; 
	});
      
}