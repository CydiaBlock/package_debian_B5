var YourName = "Aussie Appz";
var AlwaysShowIntro = true;
var TwentyFourHour = false;
var HideWidget = false;
var Success = ""; // Thank you for supporting Auzzie Appz.
