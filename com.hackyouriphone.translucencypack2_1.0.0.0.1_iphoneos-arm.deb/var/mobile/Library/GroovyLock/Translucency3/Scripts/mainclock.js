function init(){

$("#2w").animate({
  transform: 'rotate(30deg)',
},1000, "linear");
$("#3w").animate({
  transform: 'rotate(60deg)',
},1000, "linear");
$("#4w").animate({
  transform: 'rotate(90deg)',
},1000, "linear");
$("#5w").animate({
  transform: 'rotate(120deg)',
},1000, "linear");
$("#6w").animate({
  transform: 'rotate(150deg)',
},1000, "linear");
$("#7w").animate({
  transform: 'rotate(180deg)',
},1000, "linear");
$("#8w").animate({
  transform: 'rotate(210deg)',
},1000, "linear");
$("#9w").animate({
  transform: 'rotate(240deg)',
},1000, "linear");
$("#10w").animate({
  transform: 'rotate(270deg)',
},1000, "linear");
$("#11w").animate({
  transform: 'rotate(300deg)',
},1000, "linear");
$("#12w").animate({
  transform: 'rotate(330deg)',
},1000, "linear");
var currentTime = new Date();
var hrot = 360*parseInt(currentTime.getHours())/12+6*parseInt(currentTime.getMinutes())/60;
$("#hours").animate({
  transform: 'rotate('+hrot+'deg)',
},1000, "linear");
var mrot = 360*parseInt(currentTime.getMinutes())/60+6*parseInt(currentTime.getSeconds())/60;
$("#mins").animate({
  transform: 'rotate('+mrot+'deg)',
},1000, "linear");
var srot = 360*parseInt(currentTime.getSeconds())/60+6*parseInt(currentTime.getMilliseconds())/1000+6;
$("#secs").animate({
  transform: 'rotate('+srot+'deg)',
},1000, "linear");
setTimeout(function(){setInterval(updateClock, 90);}, 1000);
document.getElementById("back").style.backgroundColor=backcolor;
document.getElementById("center").style.backgroundColor=hcolor;
$( ".tick" ).css( "background-color", tcolor );
$( ".hr" ).css( "background-color", hcolor );
$( ".hb" ).css( "border-color", "transparent transparent " +hcolor+ " transparent");
$( "#border" ).css( "border", "1px solid "+tcolor );
$( "#centerb" ).css( "border", "1px solid "+ccolor );
if (b==false){document.getElementById("border").style.display="none";}
}
function updateClock() {
var currentTime = new Date();
var hrot = 360*parseInt(currentTime.getHours())/12+6*parseInt(currentTime.getMinutes())/60;
$("#hours").css('transform','rotate(+'+hrot+'deg)');
var mrot = 360*parseInt(currentTime.getMinutes())/60+6*parseInt(currentTime.getSeconds())/60;
$("#mins").css('transform','rotate(+'+mrot+'deg)');
var srot = 360*parseInt(currentTime.getSeconds())/60+6*parseInt(currentTime.getMilliseconds())/1000;
$("#secs").css('transform','rotate(+'+srot+'deg)');
}