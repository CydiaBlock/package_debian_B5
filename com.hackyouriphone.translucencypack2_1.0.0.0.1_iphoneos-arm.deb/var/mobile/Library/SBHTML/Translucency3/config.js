//Thanks for purchasing my widget pack
//configuration goes here
var instructions = true; //false to disable the popup message that gives instructions.
var ampm = true; // 12 hour clock on or off
var city = "Chapel Hill, NC"; // City and country or state (ex: "Dallas, TX", "Paris, France"), or latitude,longitude, (ex: "35.6563,-78.7588")
var gps = false; //"true" to automatically retrieve location, requires the myLocation.txt file created by Widget Weather or a comparable tweak
var iconset = "stardock"; // the weather icons, your options are: "stardock/"HTC1"/"Flat Black by LavAna"/"Flat White by LavAna"/"Flat Nano by LavAna"
var tempunit = "f"; //f or c
var batterycolor = "white"; // color of the battery bar, can be name or the HTML color code ex: "black" or "#292929"
var bottomback = "black"; // color of the background underlay behind the whole widget
var backcolor = "black"; //the color of the clock background, can be a name or HTML color code ex: "black" or "#292929"
var textcolor = "white"; // the color of the text, can be a name or HTML color code
var tcolor = "White"; //the color of the ticks on the clock, can be a name or HTML color code ex: "black" or "#292929"
var hcolor = "white"; //the color of the hands on the clock, can be a name or HTML color code ex: "black" or "#292929"
var ccolor = "black"; //the color of the center circle on the clock, can be a name or HTML color code ex: "black" or "#292929"
var clocktext = true; //enable the text clock display inside the analog clock
var b = true; //false to disable the border around the clock
var blur = true; //false if you want to disable the underlay blur of the wallpaper
var language = "en"; //en, de, it, fr, sp, or ja to change the language
//end configuration