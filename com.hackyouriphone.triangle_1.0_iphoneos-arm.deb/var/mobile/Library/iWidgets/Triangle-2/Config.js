var Scale = "0.9"; 
var Clock = "12h"; // choose between "12h" or "24h"
var Lang = "en"; 
var refreshrate = 10; // update interval of weather, in minutes
var IconWeather = "2"; // 1=White, 2=Black
var BlurBackground = false; 
var HideBackground = false; 
var BackgroundColor = "ivory"; 
var TextColor = "black"; 
var TriangleColor = "coral"; 
